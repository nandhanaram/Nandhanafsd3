import React, { useState } from 'react'

const Mapping = () => {
    var[names,setnames]=useState(["nandhana","akarsha","archana"])
  return (
    
    <div>
<ul>
    {names.map((value,index)=>{
        return(
            <li>{value}</li>
        )})}

    
    
</ul>

    </div>
  )
}

export default Mapping