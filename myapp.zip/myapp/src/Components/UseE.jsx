import { Button, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'

const UseE = () => {
    var[name,setName]=useState()
    const changehname=()=>{
        setName("Home")
    }
    const changecname=()=>{
        setName("contact")
    }
    const changegname=()=>{
        setName("gallery")
    }
    useEffect(()=>{
        changehname()
    })
  return (
    <div>
        <Typography> Welcome to{name} </Typography>
        <Button variant='contained'onClick={changehname}>Home</Button>
        <Button variant='contained'onClick={changecname}>Contact</Button>
        <Button variant='contained'onClick={changegname}>Gallery</Button>

    </div>
  )
}

export default UseE