import { Button, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'

const StateBasics = () => {
 //var name="Nandhana"
var[fname,setfname]=useState("Ramesh")
var [val,setval]=useState()
const changeName=()=>{
    console.log("clicked")
    setfname(val)
    setval(" ")
}
const inputhandler=(e)=>{
console.log(e.target.value)
setval(e.target.value)
}
  return (
    <div>
        <Typography>My name is {fname}</Typography>
        <TextField label='Enter Name' onChange={inputhandler} value={val}></TextField><br></br>
        <Button variant='contained' onClick={changeName}> change</Button>
    </div>
  )
  }

export default StateBasics