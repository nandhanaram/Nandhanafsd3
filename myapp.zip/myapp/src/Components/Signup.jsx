import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

const Signup = () => {
  return (
    <div>
        <Typography variant='h3'>SIGN UP</Typography>
        <TextField variant='outlined' label='Name'type='text'/><br></br><br></br>
        <TextField variant='outlined' label='Place'type='text'/><br></br><br></br>
        <TextField variant='outlined' label='Age'type='text'/><br></br><br></br>
        <TextField variant='outlined' label='Gender'type='text'/><br></br><br></br>
        <TextField variant='outlined' label='Email'type='email'/><br></br><br></br>
        <TextField variant='outlined' label='Password'type='password'/><br></br><br></br>
        <Button variant='contained'>Submit</Button>





    </div>
  )
}

export default Signup