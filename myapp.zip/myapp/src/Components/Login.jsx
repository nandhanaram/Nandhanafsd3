import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

const Login = () => {
  return (
    <div>
        <Typography variant='h1'>
            Helloo
        </Typography>
        <TextField variant='filled' label='username'></TextField>
        <Button variant='contained'>submit</Button>
    </div>
  )
}

export default Login