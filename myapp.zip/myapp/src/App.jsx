import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Login from './Components/Login'
import Signup from './Components/Signup'
import Navbar from './Components/Navbar'
import StateBasics from './Components/StateBasics'
import Counter from './Components/Counter'
import UseE from './Components/UseE'
import Mapping from './Components/Mapping'
import Tablearray from './Components/Tablearray'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/*<Login/>*/}
      {/*<Signup/>*/}
      <Navbar/>
     {/*<StateBasics></StateBasics>*/}
     {/*<Counter></Counter>*/}
     {/*<UseE></UseE>*/}
     {/*<Mapping></Mapping>*/}
     <Tablearray></Tablearray>
    </>
  )
}

export default App
